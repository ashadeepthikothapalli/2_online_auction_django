#from django.contrib import admin
#from django.conf.urls.static import static
#from django.contrib.staticfiles.urls import staticfiles_urlpatterns
#from django.urls import include,path


#urlpatterns = [
    #path('' , include('myapp.urls')),
  # path('admin/', admin.site.urls),
#]
from django.contrib import admin
from django.urls import path,include
from django.conf.urls import url,include
from myapp import views
urlpatterns = [
	    path('',include('myapp.urls')),
            path('admin/', admin.site.urls),
 url('register',views.register,name='register'),
    url('user_login',views.user_login,name='user_login'),
            path('index',views.index,name='index'),
            path('special',views.special,name='special'),
            path('logout', views.user_logout, name='logout'),
]
