from django.contrib import admin
from myapp.models import UserProfileInfo, User
#Register your models here.
admin.site.register(UserProfileInfo)

