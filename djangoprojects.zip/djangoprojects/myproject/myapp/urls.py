from django.urls import path
from . import views
from django.conf.urls import url
app_name = 'myapp'

urlpatterns=[
    path('',views.homeindex,name='homeindex'),
    path('user_login',views.user_login,name='user_login'),
    path('register',views.register,name='register'),
  
    path('homeindex',views.homeindex,name='home'),
    path('index',views.index,name='index'),
    path('homeindex',views.login,name='logout'),
]
